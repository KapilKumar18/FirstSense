import { Component, OnInit } from '@angular/core';
// import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';

@Component({
  selector: 'app-vplayer',
  templateUrl: './vplayer.page.html',
  styleUrls: ['./vplayer.page.scss'],
})
export class VplayerPage implements OnInit {

  public class_name = "zero_deg";

  constructor(
    // private screenOrientation: ScreenOrientation
    ) { }


  ngOnInit() {
  }

  rotate(){
    this.class_name = "ninty_deg";
  }

}
