import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VplayerPageRoutingModule } from './vplayer-routing.module';

import { VplayerPage } from './vplayer.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VplayerPageRoutingModule
  ],
  declarations: [VplayerPage]
})
export class VplayerPageModule {}
