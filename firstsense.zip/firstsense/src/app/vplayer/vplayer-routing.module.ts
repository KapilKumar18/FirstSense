import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VplayerPage } from './vplayer.page';

const routes: Routes = [
  {
    path: '',
    component: VplayerPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VplayerPageRoutingModule {}
