const firebaseConfig = {
    apiKey: "AIzaSyA65_zQ_2TkL7P8J3Wb-11Zl1Bgeg0Y1N0",
    authDomain: "fiteat-4f09c.firebaseapp.com",
    databaseURL: "https://fiteat-4f09c.firebaseio.com",
    projectId: "fiteat-4f09c",
    storageBucket: "fiteat-4f09c.appspot.com",
    messagingSenderId: "702685875474",
    appId: "1:702685875474:web:81986a7b7307b47e5df7cb",
    measurementId: "G-HLQCCKMDYL"
  };

  export default firebaseConfig;