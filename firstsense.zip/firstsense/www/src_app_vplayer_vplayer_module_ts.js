(self["webpackChunkfirstsense"] = self["webpackChunkfirstsense"] || []).push([["src_app_vplayer_vplayer_module_ts"],{

/***/ 2604:
/*!***************************************************!*\
  !*** ./src/app/vplayer/vplayer-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VplayerPageRoutingModule": () => (/* binding */ VplayerPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _vplayer_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vplayer.page */ 5669);




const routes = [
    {
        path: '',
        component: _vplayer_page__WEBPACK_IMPORTED_MODULE_0__.VplayerPage
    }
];
let VplayerPageRoutingModule = class VplayerPageRoutingModule {
};
VplayerPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], VplayerPageRoutingModule);



/***/ }),

/***/ 7291:
/*!*******************************************!*\
  !*** ./src/app/vplayer/vplayer.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VplayerPageModule": () => (/* binding */ VplayerPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _vplayer_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vplayer-routing.module */ 2604);
/* harmony import */ var _vplayer_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vplayer.page */ 5669);







let VplayerPageModule = class VplayerPageModule {
};
VplayerPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _vplayer_routing_module__WEBPACK_IMPORTED_MODULE_0__.VplayerPageRoutingModule
        ],
        declarations: [_vplayer_page__WEBPACK_IMPORTED_MODULE_1__.VplayerPage]
    })
], VplayerPageModule);



/***/ }),

/***/ 5669:
/*!*****************************************!*\
  !*** ./src/app/vplayer/vplayer.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VplayerPage": () => (/* binding */ VplayerPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_vplayer_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./vplayer.page.html */ 3297);
/* harmony import */ var _vplayer_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vplayer.page.scss */ 6766);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let VplayerPage = class VplayerPage {
    // public class_name = "zero_deg";
    constructor() { }
    ngOnInit() {
    }
};
VplayerPage.ctorParameters = () => [];
VplayerPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-vplayer',
        template: _raw_loader_vplayer_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_vplayer_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], VplayerPage);



/***/ }),

/***/ 6766:
/*!*******************************************!*\
  !*** ./src/app/vplayer/vplayer.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".input-wrapper {\n  display: flex;\n}\n\nion-icon {\n  flex: 1;\n  cursor: pointer;\n  font-size: 40px;\n}\n\n.player {\n  position: absolute;\n  bottom: 0px;\n  right: 0;\n  left: 0;\n}\n\nion-range {\n  padding: 0;\n}\n\n.rotate {\n  position: absolute;\n  top: 10px;\n  left: 10px;\n  font-size: 30px;\n}\n\n.after, .before {\n  content: \"\";\n  width: 20px;\n  height: 10px;\n  position: absolute;\n  transform: rotate(60deg);\n}\n\n.after {\n  border-bottom: 2px solid #000;\n  left: 0px;\n  top: 25px;\n  border-radius: 50%;\n}\n\n.before {\n  border-top: 2px solid #000;\n  left: 28px;\n  top: 15px;\n  border-radius: 50%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZwbGF5ZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsYUFBQTtBQUNEOztBQUVBO0VBQ0MsT0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBQ0Q7O0FBRUE7RUFDQyxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0VBQ0EsT0FBQTtBQUNEOztBQUVBO0VBQ0MsVUFBQTtBQUNEOztBQUVBO0VBQ0Msa0JBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUFDRDs7QUFFQTtFQUNHLFdBQUE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7QUFDSjs7QUFFQTtFQUNJLDZCQUFBO0VBQ0EsU0FBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksMEJBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FBQ0oiLCJmaWxlIjoidnBsYXllci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW5wdXQtd3JhcHBlcntcclxuXHRkaXNwbGF5OiBmbGV4O1xyXG59XHJcblxyXG5pb24taWNvbntcclxuXHRmbGV4OjE7XHJcblx0Y3Vyc29yOiBwb2ludGVyO1xyXG5cdGZvbnQtc2l6ZTogNDBweDtcdFxyXG59XHJcblxyXG4ucGxheWVye1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRib3R0b206MHB4O1xyXG5cdHJpZ2h0OjA7XHJcblx0bGVmdDowXHJcbn1cclxuXHJcbmlvbi1yYW5nZXtcclxuXHRwYWRkaW5nOjBcclxufVxyXG5cclxuLnJvdGF0ZXtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiAxMHB4O1xyXG5cdGxlZnQ6IDEwcHg7XHJcblx0Zm9udC1zaXplOiAzMHB4O1x0XHJcbn1cclxuXHJcbi5hZnRlciwgLmJlZm9yZXtcclxuICAgY29udGVudDonJztcclxuICAgIHdpZHRoOiAyMHB4OyBcclxuICAgIGhlaWdodDogMTBweDsgXHJcbiAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKDYwZGVnKTtcclxufVxyXG5cclxuLmFmdGVye1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICMwMDA7XHJcbiAgICBsZWZ0OjBweDtcclxuICAgIHRvcDoyNXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG59XHJcblxyXG4uYmVmb3Jle1xyXG4gICAgYm9yZGVyLXRvcDogMnB4IHNvbGlkICMwMDA7XHJcbiAgICBsZWZ0OjI4cHg7XHJcbiAgICB0b3A6MTVweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuIl19 */");

/***/ }),

/***/ 3297:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/vplayer/vplayer.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Video Player</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"light\" >\n  <div (click)=\"rotate()\">\n    <span class=\"before\"></span>\n    <ion-icon class=\"rotate\" name=\"phone-portrait-outline\"></ion-icon>\n    <span class=\"after\"></span>    \n  </div>\n  <ion-list class=\"player\">\n    \n    <ion-item >\n      <ion-range  color=\"dark\">\n        <ion-label slot=\"start\">00:00:00</ion-label>\n        <ion-label slot=\"end\">01:04:47</ion-label>\n      </ion-range>\n    </ion-item>\n     \n    <ion-item>\n        <ion-icon name=\"play-back-circle-outline\"></ion-icon>\n        <ion-icon name=\"play-skip-back-circle-outline\"></ion-icon>\n        <ion-icon name=\"play-circle-outline\"></ion-icon>\n        <ion-icon name=\"play-skip-forward-circle-outline\"></ion-icon>\n        <ion-icon name=\"play-forward-circle-outline\"></ion-icon>\n    </ion-item>\n  \n  </ion-list>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_vplayer_vplayer_module_ts.js.map